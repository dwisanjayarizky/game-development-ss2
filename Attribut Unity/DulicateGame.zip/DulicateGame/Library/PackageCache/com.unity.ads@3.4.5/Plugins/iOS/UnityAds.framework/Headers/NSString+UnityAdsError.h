#import "UnityAds.h"

@interface NSString (UnityAdsError)
- (UnityAdsError)unityAdsErrorFromString;
@end
